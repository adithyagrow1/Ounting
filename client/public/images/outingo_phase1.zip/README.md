# Outingo - Phase 1
Tourist helper website built with Bootstrap (static prototype) and Node.js backend.

## Run Static Prototype
1. Open `client/public/static-prototype/home.html` in your browser.

## Run Backend
```bash
cd server
npm install express cors
node server.js
```
