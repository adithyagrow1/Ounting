import React from 'react'
import { Routes, Route, Link } from 'react-router-dom'
import Home from './pages/Home'
import Explore from './pages/Explore'
import Profile from './pages/Profile'
import Navbar from './components/Navbar'
import Footer from './components/Footer'

export default function App(){
  return (
    <>
      <Navbar />
      <div className="container my-4">
        <Routes>
          <Route path="/" element={<Home/>} />
          <Route path="/explore" element={<Explore/>} />
          <Route path="/profile" element={<Profile/>} />
        </Routes>
      </div>
      <Footer />
    </>
  )
}
