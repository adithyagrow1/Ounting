import React from 'react'

export default function Profile(){
  return (
    <div>
      <h2>Your Profile</h2>
      <p>This is a stub profile for Phase 1. Saved places will appear here.</p>
    </div>
  )
}
