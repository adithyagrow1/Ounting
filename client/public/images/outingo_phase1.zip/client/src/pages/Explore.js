import React, { useEffect, useState } from 'react'
import axios from 'axios'
import LocationCard from '../components/LocationCard'

export default function Explore(){
  const [query, setQuery] = useState('')
  const [locations, setLocations] = useState([])
  const [loading, setLoading] = useState(false)

  useEffect(()=>{
    const controller = new AbortController()
    setLoading(true)
    axios.get('http://localhost:4000/api/locations', { params: { q: query }, signal: controller.signal })
      .then(r => setLocations(r.data))
      .catch(err => console.error(err))
      .finally(()=> setLoading(false))
    return ()=> controller.abort()
  }, [query])

  return (
    <div>
      <div className="mb-3">
        <input className="form-control" placeholder="Search city or place..." value={query} onChange={(e)=>setQuery(e.target.value)} />
      </div>

      {loading ? <p>Loading...</p> : (
        <div className="row g-3">
          {locations.map(l => (
            <div className="col-md-4" key={l.id}>
              <LocationCard {...l} />
            </div>
          ))}
        </div>
      )}
    </div>
  )
}
